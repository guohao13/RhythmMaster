package RytmMaster_vol2;

public class Main {

	public static final int SCREEN_WIDTH = 1280;
	public static final int SCREEN_HEIGHT = 720;
	public static final int NOTE_SPEED = 7;
	public static final int SLEEP_TIME = 10;
	public static final int REACH_TIME = 1;
	
	public static void main(String[] args) {
		
		new DynamicBeat();

	}

}
